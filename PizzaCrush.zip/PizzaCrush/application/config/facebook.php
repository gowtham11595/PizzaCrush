<?php
	$config['appId'] 			= '594610940582342';
	$config['secret'] 			= '4099d252eaaad47ef9a68570a4f7e7b2';
?>
